

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class billServlet
 */
@WebServlet("/billServlet")
public class billServlet extends HttpServlet {
	private final static String query = "insert into history(customerName,mobileNu,total_cost) values(?,?,?)";
	
       
    
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		//pint writer add
				PrintWriter pw=res.getWriter();
				//content
				res.setContentType("text/html");
				// get the values
				String customerName = req.getParameter("customerName");
				int  mobileNu= Integer.parseInt(req.getParameter("mobileNu"));
				float  total_cost= Float.parseFloat(req.getParameter("total_cost"));
				
				//connect the jdbc driver
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
				} catch (Exception e) {
					e.printStackTrace();
				}
				try(Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/medical","root","Sergio45#");
						PreparedStatement ps = con.prepareStatement(query);){
		            //set the values
		            ps.setString(1, customerName);
		            
		            ps.setInt(2, mobileNu);
		            ps.setFloat(3, total_cost);
		            //execute the query
		            int count = ps.executeUpdate();
		            if(count==1) {
		            	RequestDispatcher rd=req.getRequestDispatcher("home.html");
		            	rd.include(req, res);
		            	
		            }
		            else {
		            	
		    			pw.println("Something went wrong");
		            	RequestDispatcher rd=req.getRequestDispatcher("contact.html");
		            }
		            
		        }catch(SQLException se) {
		            pw.println(se.getMessage());
		            se.printStackTrace();
		        }catch(Exception e) {
		        	pw.println(e.getMessage());
		            e.printStackTrace();
		        }
		        
		        //close the stram
		        pw.close();
	}

	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(req, res);
	}

}
